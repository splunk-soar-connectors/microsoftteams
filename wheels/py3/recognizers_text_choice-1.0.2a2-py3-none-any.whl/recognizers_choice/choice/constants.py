class Constants:
    SYS_BOOLEAN: str = "boolean"
    SYS_BOOLEAN_TRUE: str = "boolean-true"
    SYS_BOOLEAN_FALSE: str = "boolean-false"
