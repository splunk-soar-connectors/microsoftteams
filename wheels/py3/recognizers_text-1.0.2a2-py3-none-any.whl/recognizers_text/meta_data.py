class MetaData:
    def __init__(self):
        self.has_mod: bool = False
        self.is_duration_with_ago_and_later = False
